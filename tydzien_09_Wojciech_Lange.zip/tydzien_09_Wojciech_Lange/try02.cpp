#include "std_lib_facilities.hpp"

typedef vector<string>::const_iterator Line_iter;

class Message{
    Line_iter first;
    Line_iter last;

public:
    Message(Line_iter p1, Line_iter p2) :first{p1}, last{p2} {}
    Line_iter begin() const {return first;}
    Line_iter end() const { return last; }

    Message(string dev) {};
 };

class Device
{
    string dev_name;

public:
    Device(string name) :dev_name{name} {}
};

Message* get_input(Device&)
{
    Message* mes = new Message("test");
    return mes;
};

class Node{
    int jakas_liczba;
};



int main()
{
    int i = 0;

    Device dev = Device("test");

    while(i<2){
        Node* n1 = new Node;
        Node* n2 = new Node;
        Message* p = get_input(dev);

        cout<<"n1 = "<<n1<<" size: "<<sizeof(n1)<<'\n';
        cout<<"n2 = "<<n2<<" size: "<<sizeof(n2)<<'\n';
        cout<<"p = "<<p<<" size: "<<sizeof(p)<<'\n';

        delete p;

        ++i;
    }


}