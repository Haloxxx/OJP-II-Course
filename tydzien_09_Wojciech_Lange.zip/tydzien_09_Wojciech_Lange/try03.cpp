#include "std_lib_facilities.hpp"

int main()
{
    //char I;
    for(int i; cin>>i; )
        cout<<dec<<i<<"=="
        <<hex<<"0x"<<i<<"=="
        <<bitset<8*sizeof(int)>{static_cast<unsigned long long>(i)}<<'\n';
}