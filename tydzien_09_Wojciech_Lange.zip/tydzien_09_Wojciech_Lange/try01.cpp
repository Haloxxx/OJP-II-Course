#include "std_lib_facilities.hpp"

int main()
{

    float x = 1.0/10;
    float sum = 0;
    for (int i=0; i<10; ++i) sum+=x;
    cout << setprecision(15) << sum << "\n";


}