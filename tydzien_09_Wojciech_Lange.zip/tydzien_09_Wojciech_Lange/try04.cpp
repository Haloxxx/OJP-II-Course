#include "std_lib_facilities.hpp"

template<typename T> void print(T s)
{
    cout<<int(s)<<" ";
}

int main()
{
    int si = 128;
    char c = si;
    unsigned char uc = si;
    signed char sc = si;
    print(si); print(c); print(uc); print(sc); cout<<'\n';
}