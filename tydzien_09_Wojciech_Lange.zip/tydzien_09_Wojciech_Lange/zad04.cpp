#include "std_lib_facilities.hpp"

int main()
{
    signed int integer = 0b00000000000000000000000000000000;
    cout<<integer<<'\n';
    
    
    signed int integer2 = 0b11111111111111111111111111111111;
    cout<<integer2<<'\n';
    
    
    integer = 0b10101010101010101010101010101010;
    cout<<integer<<'\n';

    integer = integer xor integer2;
    cout<<integer<<'\n';
    //cout<<bitset<32>{static_cast<unsigned long long>(integer)}<<'\n';
    integer = 0b11001100110011001100110011001100;
    cout<<integer<<'\n';

    integer = integer xor integer2;
    cout<<integer<<'\n';

    integer = 0b11110000111100001111000011110000;
    cout<<integer<<'\n';

    integer = integer xor integer2;
    cout<<integer<<'\n';
    //cout<<bitset<32>{static_cast<unsigned long long>(integer)}<<'\n';
    
    //integer = 0b11111111111111111111111111111111;
    //cout<<integer<<'\n';

    


    ///////////////////////
    ///////////////////////
    //////////////////////

    unsigned int uinteger = 0b00000000000000000000000000000000;
    cout<<uinteger<<'\n';
    
    
    unsigned int uinteger2 = 0b11111111111111111111111111111111;
    cout<<uinteger2<<'\n';
    
    
    uinteger = 0b10101010101010101010101010101010;
    cout<<uinteger<<'\n';

    uinteger = uinteger xor uinteger2;
    cout<<uinteger<<'\n';
    //cout<<bitset<32>{static_cast<unsigned long long>(integer)}<<'\n';
    uinteger = 0b11001100110011001100110011001100;
    cout<<uinteger<<'\n';

    uinteger = uinteger xor uinteger2;
    cout<<uinteger<<'\n';

    uinteger = 0b11110000111100001111000011110000;
    cout<<uinteger<<'\n';

    uinteger = uinteger xor uinteger2;
    cout<<uinteger<<'\n';




    //cout<<"sizeof = "<<sizeof(integer)*8<<'\n';

    

}