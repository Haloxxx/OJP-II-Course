#include "std_lib_facilities.hpp"
#include "Matrix.hpp"
#include <complex>
#include "MatrixIO.hpp"


int main()
{/*
    cout<<"size of char: "<<sizeof(char)<<'\n';
    cout<<"size of short: "<<sizeof(short)<<'\n';
    cout<<"size of int: "<<sizeof(int)<<'\n';
    cout<<"size of long: "<<sizeof(long)<<'\n';
    cout<<"size of float: "<<sizeof(float)<<'\n';
    cout<<"size of double: "<<sizeof(double)<<'\n';
    cout<<"size of int*: "<<sizeof(int*)<<'\n';
    cout<<"size of double*: "<<sizeof(double*)<<'\n';


    Numeric_lib::Matrix<int> a(10);
    cout<<"size of Matrix<int> a(10): "<<sizeof(a)<<'\n';

    Numeric_lib::Matrix<int> b(100);
    cout<<"size of Matrix<int> b(100): "<<sizeof(b)<<'\n';

    Numeric_lib::Matrix<double> c(10);
    cout<<"size of Matrix<double> c(10): "<<sizeof(c)<<'\n';

    Numeric_lib::Matrix<int,2> d(10,10);
    cout<<"size of Matrix<int,2> d(10,10): "<<sizeof(d)<<'\n';

    Numeric_lib::Matrix<int,3> e(10,10,10);
    cout<<"size of Matrix<int,3> e(10,10,10): "<<sizeof(e)<<'\n';

    cout<<"Number of elements of Matrix<int> a(10): "<<a.size()<<'\n';
    cout<<"Number of elements of Matrix<int> b(100): "<<b.size()<<'\n';
    cout<<"Number of elements of Matrix<double> c(10): "<<c.size()<<'\n';
    cout<<"Number of elements of Matrix<int,2> d(10,10): "<<d.size()<<'\n';
    cout<<"Number of elements of Matrix<int,3> e(10,10,10): "<<e.size()<<'\n';



    int number;

    while(cin>>number)
    {
       
        //sqrt(number);
        
        if(isnan(sqrt(number))) cout<<"no square root\n";
        else cout<<sqrt(number)<<'\n';
    }



    Numeric_lib::Matrix<double> fifth(10);

    for(int i = 0; i<10; ++i)
    {
        double input;

        cin>>input;

        fifth[i]=input;
    }

    double* mat = fifth.data();
    for(int i = 0; i<fifth.size(); ++i)
    {
        cout<<mat[i]<<" ";
    }



    int n, m;

    cout<<"n: ";
    cin>>n;
    cout<<"m: ";
    cin>>m;

    Numeric_lib::Matrix<int,2> multiplication_table(n,m);

    vector<int> column;
    vector<int> row;

    for(int i=0; i<m; ++i)
        column.push_back(i);

    for(int i =0; i<n; ++i)
        row.push_back(i);

    for(int i =0; i<m; ++i)
    {
        for(int j =0; j<n; ++j)
        {
            multiplication_table[i][j]=column[i]*row[j];
        }
    }

    for(int i =0; i<m; ++i)
    {
        for(int j =0; j<n; ++j)
        {
            cout<<setw(3)<<multiplication_table[i][j]<<" ";
        }
        cout<<'\n';
    }



    Numeric_lib::Matrix<complex<double>> complex_matrix(10);
    
    for(int i = 0; i<10; ++i)
    {
        complex<double> complex_number;
        cin>>complex_number;
        complex_matrix[i]=complex_number;
    }

    complex<double> complex_sum = 0;

    for(int i = 0; i<10; ++i)
        complex_sum += complex_matrix[i];

    cout<<"complex sum = "<<complex_sum<<'\n';

*/

    Numeric_lib::Matrix<int,2> m(2,3);

    for(int i =0; i<2; ++i)
    {
        for(int j =0; j<3; ++j)
        {
            int integer_number;
            cin>>integer_number;
            m[i][j]=integer_number;
        }
    }
    for(int i =0; i<2; ++i)
    {
        for(int j =0; j<3; ++j)
            cout<<m[i][j]<<" ";
        cout<<'\n';
    }
}