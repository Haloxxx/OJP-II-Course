#include "std_lib_facilities.hpp"

int main()
{
    unsigned int v = 1; for (int i = 0; i<sizeof(v)*8; ++i) { cout<<v<<' '; v<<=1; }

    
    short unsigned int literal = 0xff;
    cout<<"1: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';
    literal = 0x01;
    cout<<"2: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';
    literal = 0x80;
    cout<<"3: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';
    literal = 0x00;
    cout<<"4: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';
    literal = 0xff;
    cout<<"5: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';
    literal = 0x55;
    cout<<"6: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';
    literal = 0xaa;
    cout<<"7: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';

    literal = 1;
    literal = literal<<7;
    short unsigned int lit1 = 1, lit2 = 1, lit3 = 1, lit4 =1 , lit5 =1 , lit6 =1, lit7=1, lit8 = 1;
    lit1 = lit1<<7;
    lit2 = lit2<<6;
    lit3 = lit3<<5;
    lit4 = lit4<<4;
    lit5 = lit5<<3;
    lit6 = lit6<<2;
    lit7 = lit7<<1;
    //cout<<bitset<8>{lit2}<<'\n';
    literal = literal | lit2 | lit3| lit4|lit5|lit6|lit7|lit8;
    cout<<"1: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';
    literal = lit8;
    cout<<"2: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';
    literal = 1;
    literal = literal<<7;
    cout<<"3: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';
    literal = 0;//lit5|lit6|lit7|lit8;
    cout<<"4: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';
    literal = lit1|lit2 | lit3| lit4|lit5|lit6|lit7|lit8;
    cout<<"5: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';
    literal = lit2|lit4|lit6|lit8;
    cout<<"6: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';
    literal = literal&literal;
    literal = literal<<1;
    cout<<"7: "<<dec<<literal<<" hex - "<<hex<<literal<<'\n';

    //cout<<bitset<8>{literal}<<'\n';




}