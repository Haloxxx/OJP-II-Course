#include "std_lib_facilities.hpp"
#include "Matrix.hpp"
#include "MatrixIO.hpp"



/*
void triple1(int& x)
{
    x*=3;
}

int triple2(int x)
{
    return 3*x;
}

int triple(int& x) //Taka funkcja jednocześnie zmienia dane wejściowe i zwraca wynik, co moze wywoływać chaos
{
    int a = x;
    x*=3;
    return 3*a;
}


int main()
{
    Numeric_lib::Matrix<int> a(5);
    Numeric_lib::Matrix<int> b(5);

    for(int i =0; i<5; ++i)
        a[i]=i+1;

    a.apply(triple);
    b = Numeric_lib::apply(triple, a);
    
    for(int i =0; i<5; ++i)
        cout<<a[i]<<" ";

    cout<<'\n';

    for(int i =0; i<5; ++i)
        cout<<b[i]<<" ";
    

}*/

struct triple1
{
    void operator()(int& a) { a *= 3; }
};

struct triple2
{
    int operator()(int a) { return 3*a; }
};

struct triple //analogicznie jak powyzej
{
    int operator()(int& x) {int a = x; x*=3; return 3*a;}
};



int main()
{

    Numeric_lib::Matrix<int> a(5);
    Numeric_lib::Matrix<int> b(5);

    for(int i =0; i<5; ++i)
        a[i]=i+1;

    a.base_apply(triple());
    b = Numeric_lib::apply(triple(), a);

    for(int i =0; i<5; ++i)
        cout<<a[i]<<" ";

    cout<<'\n';

    for(int i =0; i<5; ++i)
        cout<<b[i]<<" ";

}