/*#include "std_lib_facilities.hpp"

class Int
{
    int val;

public:
    Int(int number): val {number} {};
    Int(): val {0} {};

    void operator=(const int v){val = v;};
    Int operator+(const Int v) {return val+v.val;}
    Int operator-(const Int v) {return val-v.val;}
    Int operator*(const Int v) {return val*v.val;}
    Int operator/(const Int v) {return val/v.val;}

    
    
    int get(){return val;}
    void set(int h){val = h;}
};




ostream& operator<<(ostream& ist, Int v){ return ist<<v.get(); };



int main()
{
    Int a;

    Int b(5);

    cout<<(a+b)<<'\n';

}*/

#include "std_lib_facilities.hpp"

template<class T> class Number
{
    T val;

public:
    Number(int number): val {number} {};
    Number(): val {0} {};

    void operator=(const T v){val = v;};
    Number operator+(const Number v) {return val+v.val;}
    Number operator-(const Number v) {return val-v.val;}
    Number operator*(const Number v) {return val*v.val;}
    Number operator/(const Number v) {return val/v.val;}
    Number operator%(const Number v) {return val%v.val;}

    
    
    int get(){return val;}
    void set(T h){val = h;}
};

int main()
{
    Number<double> d;
    Number<int> i;

    d%i;
}