#include "std_lib_facilities.hpp"


int main()
{
    //////////////////////////////
    /*Wskazane przypadki powinny pozwolić nam na wykluczenie błędow w implementacji resize().
    Zarowno dla liczby 0 jak i liczb ujemnych funkcja powinna zachować się prawidłowo,
    poniewaz reserve(), jest przed nimi zabezpieczona, a pętla iteruje dla i<newsize.
    ////////////////////////////*/
}