#include "std_lib_facilities.hpp"


template<typename T, typename U>
T sum_of_products(vector<T> vt, vector<U> vu)
{
    T sum = 0;

    for(int i =0; i<vt.size(); ++i)
    {
        sum+=vt[i]*vu[i];
    }

    return sum;
}

int main()
{

}