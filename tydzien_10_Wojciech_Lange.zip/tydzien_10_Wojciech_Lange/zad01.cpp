#include "std_lib_facilities.hpp"


template<typename T> struct S { 
private:
    T val; 
public:
    S(T sth) : val{sth} {}; 


    T& get();
    const T& get() const;
    void set(T t);
    void operator=(const T& t);

};

template<typename T>
T& S<T>::get() { return val; }

template<typename T>
const T& S<T>::get() const { return val; }

template<typename T>
void S<T>::set(T t) { val = t; }

template<typename T>
void S<T>::operator=(const T& t) 
{
    val = t;
}

template<typename T>
void read_val(T& v)
{
    cin>>v;
}

template<typename T>
istream& operator>>(istream& ist, vector<T>& v) 
{
    char begin, end;

    cin>>begin;

    T pp;

    while(cin>>pp)
        v.push_back(pp);
}

template<typename T>
ostream& operator<<(ostream& ist, vector<T>& v) 
{
    char begin = '{', end = '}';

    cout<<begin<<" ";

    for(int i =0; i<v.size(); ++i)
        cout<<v[i]<<", ";

    cout<<end;

}


int main()
{
    int a;
    char b;
    double c;
    string d;
    vector<int> e;

    /*cin>>a;
    cin>>b;
    cin>>c;
    cin>>d;
    for(int i; cin>>i; )
        e.push_back(i);
*/
/*
    a = 5;
    b = 'a';
    c = 2.0;
    d = "slowo";*/
    e  = {1, 2, 3, 4, 5};

    read_val(a);
    read_val(b);
    read_val(c);
    read_val(d);

    S<int> liczba(a);
    S<char> znak(b);
    S<double> liczba_przecinek(c);
    S<string> ciag(d);
    S<vector<int>> wektor(e);
    
    cout<<liczba.get()<<'\n';
    cout<<znak.get()<<'\n';
    cout<<liczba_przecinek.get()<<'\n';
    cout<<ciag.get()<<'\n';
    
    for(int i =0; i<wektor.get().size(); ++i)
        cout<<wektor.get()[i]<<" ";

    cout<<'\n';
}