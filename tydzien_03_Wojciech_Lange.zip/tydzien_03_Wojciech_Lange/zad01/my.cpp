#include "my.hpp"
#include "std_lib_facilities.hpp"

int foo;

void print_foo()
{
    cout<<foo;
}


void print(int i)
{
    cout<<i;
}
