#include "my.hpp"
#include "my.cpp"

int main()
{
    foo = 7;
    
    print_foo();
    print(99);
    
    return 0;
}
