#include "std_lib_facilities.hpp"


class Rational
{
private:
    int numerator, denominator;
    
public:
    Rational(int numerator, int denominator);
    int up() const {return numerator;}
    int down() const {return denominator;}
    Rational assignment();
    double conversion() {return numerator/double(denominator);}
};


Rational::Rational(int num, int denom)
:numerator{num},denominator{denom}
{
    if (denominator==0) error("Zero division");
        if (denominator<0)
        {
            numerator*=-1;
            denominator*=-1;
        }
}


Rational Rational::assignment()
{
    int numerator = 0,denominator = 1;
    
    
    cout<<"Enter your number:\n";
    cin>>numerator;
    cout<<"–\n";
    cin>>denominator;
    

    return Rational{numerator,denominator};
}


bool operator==(const Rational& val1, const Rational& val2)
{
    if (val1.up()==val2.up() && val1.down()==val2.down()) return 1;
    else if (val1.up()/double(val2.up())==val1.down()/double(val2.down())) return 1;
    else return 0;
}

bool operator!=(const Rational& val1, const Rational& val2)
{
    if (val1.up()/double(val2.up())!=val1.down()/double(val2.down())) return 1;
    else return 0;
}

bool operator<=(const Rational& val1, const Rational& val2)
{
    if (val1.up()/double(val2.up())<=val1.down()/double(val2.down())) return 1;
    else return 0;
}

bool operator>=(const Rational& val1, const Rational& val2)
{
    if (val1.up()/double(val2.up())>=val1.down()/double(val2.down())) return 1;
    else return 0;
}

bool operator<(const Rational& val1, const Rational& val2)
{
    if (val1.up()/double(val2.up())<val1.down()/double(val2.down())) return 1;
    else return 0;
}

bool operator>(const Rational& val1, const Rational& val2)
{
    if (val1.up()/double(val2.up())>val1.down()/double(val2.down())) return 1;
    else return 0;
}


Rational operator+(const Rational& val1, const Rational& val2)
{
    int numerator = 0,denominator = 1;
    
    if (val1.down()!=val2.down())
    {
        denominator=val1.down()*val2.down();
        numerator=val1.up()*val2.down()+val2.up()*val1.down();
    }
    else
    {
        denominator=val1.down();
        numerator=val1.up()+val2.up();
    }
    
    return Rational{numerator,denominator};
}


Rational operator-(const Rational& val1, const Rational& val2)
{
    int numerator = 0,denominator = 1;
    
    if (val1.down()!=val2.down())
    {
        denominator=val1.down()*val2.down();
        numerator=val1.up()*val2.down()-val2.up()*val1.down();
    }
    else
    {
        denominator=val1.down();
        numerator=val1.up()-val2.up();
    }
 
    return Rational{numerator,denominator};
    
}

Rational operator*(const Rational& val1, const Rational& val2)
{
    int numerator = 0,denominator = 1;
    
    numerator=val1.up()*val2.up();
    denominator=val1.down()*val2.down();
    
    return Rational{numerator,denominator};
    
}


Rational operator/(const Rational& val1, const Rational& val2)
{
    int numerator = 0,denominator = 1;
    Rational temporary{0,1};
    
    denominator = val2.up();
    numerator=val2.down();
    
    temporary = val1*Rational{numerator,denominator};
    return Rational{temporary.up(),temporary.down()};
}



int main()
{
    Rational liczba1{1,2}, liczba2{1,3}, wynik{0,1}, wynik2{0,1};
    
    if (liczba1/liczba2==Rational{3,2}) cout<<"HA\n";
}
