#include "std_lib_facilities.hpp"

int main()
{
    
    int n;
    
    cin>>n;
    
    
    vector<string> name(n);
    vector<int> age(n);
    vector<string> c_name(n);
    vector<int> c_age(n);
    
    for(int i =0; i<n; i++) cin>>name[i];
    
    cout<<"Please enter age of each person.\n";
    
    for(int i =0; i<n; i++) cin>>age[i];
    
    for(int i =0; i<n; i++) cout<<name[i]<<" "<<age[i]<<'\n';
    
    for(int i =0; i<n; i++) c_name[i]=name[i];
    
    
    cout<<"\n\n\n";
    
    sort(name.begin(),name.end());
    
    
    for(int j=0; j<n; j++)
    {
            for(int i =0; i<n; i++)
            {
                if (c_name[j]==name[i]) c_age[i]=age[j];
            }
    }
    
    for(int i =0; i<n; i++) cout<<name[i]<<" "<<c_age[i]<<'\n';
    
}
