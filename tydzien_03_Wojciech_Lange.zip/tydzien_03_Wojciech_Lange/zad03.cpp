#include "std_lib_facilities.hpp"

/*Version 1
struct Date
{
    int y;
    int m;
    int d;
};


void init_day(Date& dd, int y, int m, int d)
{
    if (y<0) error("Year is negative");
    if (m<1||m>12) error("Bad month");
    if (d<1||d>31) error("Bad day");
    
    dd.y=y;
    dd.m=m;
    dd.d=d;
}

void add_day(Date& dd, int n)
{
    dd.d+=n;
    while(dd.d>31)
    {
        dd.d-=31;
        ++dd.m;
    }
}

ostream& operator<<(ostream& os, const Date& d)
{
    return os<<'('<<d.y
                <<','<<d.m
    <<','<<d.d<<')';
}


int main()
{
    
    Date today;
    init_day(today,1978,06,25);
    //init_day(today,2004,13,-5);
    
    Date tomorrow;
    tomorrow = today;
    add_day(tomorrow, 1);
    
    cout<<today<<tomorrow;
    
}
*/

/*Version 2

struct Date {
    int y, m, d;
    Date(int y, int m, int d);
    void add_day(int n);
};

Date::Date(int yy, int mm, int dd)
:y{yy},m{mm},d{dd}
{
    if (y<0) error("Year is negative");
    if (m<1||m>12) error("Bad month");
    if (d<1||d>31) error("Bad day");
}

void add_day(Date& dd, int n)
{
    dd.d+=n;
    while(dd.d>31)
    {
        dd.d-=31;
        ++dd.m;
        if (dd.m>12)
        {
            dd.m-=12;
            ++dd.y;
        }
    }
}

ostream& operator<<(ostream& os, const Date& d)
{
    return os<<'('<<d.y
    <<','<<d.m
    <<','<<d.d<<')';
}


int main()
{
    
    Date today{1978,06,25};
    //Date today(2004,13,-5);
    
    Date tomorrow = today;
    add_day(tomorrow, 1);
    
    cout<<today<<tomorrow;
    
}
*/

/*Version 3

class Date {
    int y, m, d;
public:
    Date(int y, int m, int d);
    void add_day(int n);
    int month() { return m; }
    int day() { return d; }
    int year() { return y; }
    
};

Date::Date(int yy, int mm, int dd)
:y{yy},m{mm},d{dd}
{
    if (y<0) error("Year is negative");
        if (m<1||m>12) error("Bad month");
            if (d<1||d>31) error("Bad day");
}

void Date::add_day(int n)
{
    d+=n;
    while(day()>31)
    {
        d-=31;
        ++m;
        if (m>12)
        {
            m-=12;
            ++y;
        }
    }
}

ostream& operator<<(ostream& os, Date& d)
{
    return os<<'('<<d.year()
    <<','<<d.month()
    <<','<<d.day()<<')';
}


int main()
{
    
    Date today{1978,06,25};
    //Date today(2004,13,-5);
    
    Date tomorrow = today;
    tomorrow.add_day(1);
    
    cout<<today<<tomorrow;
    
}

*/


/*Version 4

enum class Month {
    jan=1, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec };


class Year { // year in [min:max) range
    static const int min = 1800;
    static const int max = 2200;
public:
    class Invalid { };
    Year(int x) : y{x} { if (x<min || max<=x) throw Invalid{};}
    int year() { return y; }
private:
    int y;
};


class Date {
public:
    Date(Year y, Month m, int d);
    void add_day(int n);
    Month month() { return m; }
    int day() { return d; }
    Year year() { return y; }
    
private:
    Year y;
    Month m;
    int d;
};

Date::Date(Year yy, Month mm, int dd)
:y{yy},m{mm},d{dd}
{
            if (d<1||d>31) error("Bad day");
                }

void Date::add_day(int n)
{
    d+=n;
    while(day()>31)
    {
        d-=31;
        
    }
}


ostream& operator<<(ostream& os, Year y)
{
    return os<<y.year();
}


ostream& operator<<(ostream& os, Month m)
{
    int i = static_cast<int> (m);
    return os<<i;
}

ostream& operator<<(ostream& os, Date& d)
{
    return os<<'('<<d.year()
    <<','<<d.month()
    <<','<<d.day()<<')';
}


int main()
{
    
    Date today{Year{1978},Month{6},25};
    //Date today(Year{2004},Month{13},-5);
    
    Date tomorrow = today;
    tomorrow.add_day(1);
    
    cout<<today<<tomorrow;
    
}

*/

//Version 5

 enum class Month {
 jan=1, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec };
 

 
 class Date {
 public:
     Date(int y, Month m, int d);
     void add_day(int n);
     Month month() const { return m; }
     int day() const { return d; }
     int year() const { return y; }
 
 private:
 int y;
 Month m;
 int d;
 };
 
 Date::Date(int yy, Month mm, int dd)
 :y{yy},m{mm},d{dd}
 {
 if (d<1||d>31) error("Bad day");
 }
 
 void Date::add_day(int n)
 {
 d+=n;
 while(day()>31)
 {
 d-=31;
 
 }
 }
 
 
 ostream& operator<<(ostream& os, Month m)
 {
 int i = static_cast<int> (m);
 return os<<i;
 }
 
 
 ostream& operator<<(ostream& os, Date& d)
 {
 return os<<'('<<d.year()
 <<','<<d.month()
 <<','<<d.day()<<')';
 }
 
 
 int main()
 {
 
     Date today{1978,Month{6},25};
     //Date today(2004,Month{13},-5);
 
 Date tomorrow = today;
 tomorrow.add_day(1);
 
 cout<<today<<tomorrow;
 
 }

