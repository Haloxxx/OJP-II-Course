#include "std_lib_facilities.hpp"


void print_array10(ostream& os, int* a)
{
    for(int i =0; i<10; ++i) os<<a[i]<<" ";
}

void print_array(ostream& os, int* a, int n)
{
    for(int i =0; i<n; ++i) os<<a[i]<<" ";
}

void print_vector(ostream& os, vector<int> v)
{
    for(int i =0; i<v.size(); ++i) os<<v[i]<<" ";
}

int main()
{
    
    int* one = new int[10];

    for(int i =0; i<10; ++i) cout<<one[i]<<" ";

    delete[] one;


    int* two = new int[10] {100, 101, 102, 103, 104, 105, 106, 107, 108, 109};

    print_array10(cout, two);

    int* three = new int[11] {100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110};

    for(int i =0; i<11; ++i) cout<<three[i]<<" ";

    int* four = new int[20] {100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119};

    print_array(cout, four, 20);

    delete[] two;
    delete[] three;
    delete[] four;

    vector<int> v1 {100, 101, 102, 103, 104, 105, 106, 107, 108, 109};
    print_vector(cout, v1);

    vector<int> v2 {100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110};
    print_vector(cout, v2);

    vector<int> v3 {100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119};
    print_vector(cout, v3);


///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
//////////////////////////////PART2//////////////////////////////
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////

    int* p1 = new int{7};

    cout<<"p1 = "<<p1<<'\n';
    cout<<"p1 points to "<<*p1<<'\n';

    int* p2 = new int[7] {1, 2, 4, 8, 16, 32, 64};

    cout<<"p2 = "<<p2<<'\n';
    cout<<"p2 points to:\n";
    for(int i =0; i<7; ++i) cout<<p2[i]<<" ";

    int* p3 = p2;

    p2 = p1;
    p2 = p3;

    cout<<"\np1 = "<<p1<<'\n';
    cout<<"p1 points to "<<*p1<<'\n';

    cout<<"p2 = "<<p2<<'\n';
    cout<<"p2 points to:\n";
    for(int i =0; i<7; ++i) cout<<p2[i]<<" ";

    delete p1;
    delete[] p2; 

    p1 = new int[10] {1, 2, 4, 8, 16, 32, 64, 128, 256, 512};
    p2 = new int[10];
    
    for(int i =0; i<10; ++i) p2[i]=p1[i];

    vector<int> vec1 {1, 2, 4, 8, 16, 32, 64, 128, 256, 512};
    vector<int> vec2(10);

    vec2=vec1;
    
    
}