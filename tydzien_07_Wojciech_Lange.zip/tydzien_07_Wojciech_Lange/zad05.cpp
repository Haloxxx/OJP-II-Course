#include "std_lib_facilities.hpp"


int global_1, global_2;


int* f()
{
    int funkcja;
    int funkcja2;

    int* stack_1 = &funkcja;
    int* stack_2 = &funkcja2;

    //cout<<stack_1<<" "<<stack_2<<'\n';

    if(stack_1<stack_2) cout<<"Adresy w stacku są coraz większe\n";
    else cout<<"Adresy w stacku są coraz mniejsze\n";

    //cout<<"stack = "<<stack_1<<'\n';

    return stack_1;
}


vector<int*> bubbleSort(vector<int*> A)
{
  int n = A.size();
   do
   {
    for (int i = 0; i < n-1; i++) 
    {
        if (A[i] > A[i+1]) 
            swap(A[i], A[i+1]);
    }
    n = n-1;
   } while (n > 1);

   return A;
}

int main()
{

    int* static_1 = &global_1;
    int* static_2 = &global_2;

    //cout<<"static = "<<static_1<<" "<<static_2<<'\n';

    int* stack_1 = f();

    int* new_1 = new int[4];

    int* a1 = &new_1[0];
    int* a2 = &new_1[1];


    //cout<<a1<<" "<<a2<<'\n';
    if(a1<a2) cout<<"Adresy w tablicy na Free store są coraz większe\n";
    else cout<<"Adresy w tablicy na Free store są coraz mniejsze\n";

    //cout<<"new = "<<new_1<<'\n';

    vector<int*> adresses;
    vector<int*> sorted;

    adresses.push_back(static_1);
    adresses.push_back(stack_1);
    adresses.push_back(new_1);

    sorted = bubbleSort(adresses);

    vector<string> result(3);

    for(int i =0; i<3; ++i)
    {
        if(sorted[i]==adresses[0]) result[i]="Static data";
        if(sorted[i]==adresses[1]) result[i]="Stack";
        if(sorted[i]==adresses[2]) result[i]="Free store";
    }

    for(int i =0; i<3; ++i) cout<<i+1<<". "<<result[i]<<'\n';
}