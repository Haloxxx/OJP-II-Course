#include "std_lib_facilities.hpp"


void sizes(char ch, int i, int* p, bool st, double d, string s)
{
    cout << "the size of char is " << sizeof(char) << ' ' << sizeof (ch) << '\n';
    cout << "the size of int is " << sizeof(int) << ' ' << sizeof (i) << '\n';
    cout << "the size of int* is " << sizeof(int*) << ' ' << sizeof (p) << '\n';
    cout << "the size of bool is " << sizeof(bool) << ' ' << sizeof (st) << '\n';
    cout << "the size of double is " << sizeof(double) << ' ' << sizeof (d) << '\n';
    cout << "the size of string is " << sizeof(string) << ' ' << sizeof (s) << '\n';
}


int main()
{
    int d = 15;
    int* pd = &d;
    string test = "fajnie";
    
    
    sizes('c', 500, pd, false, 81.3, test);
    
}
