#include "std_lib_facilities.hpp"

class test{
    
    public:
        test()
        {
            cout<<"New object of 'try' created!\n";
        }

        ~test()
        {
            cout<<"Object destroyed!\n";
        }

};


void pp()
{
    test object;
}

int main()
{

    pp();

    test object;


    if(1) test object3;

}