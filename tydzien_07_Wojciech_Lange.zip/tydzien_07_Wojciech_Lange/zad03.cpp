#include "std_lib_facilities.hpp"


int ga[10] {1,2,4,8,16,32,64,128,256,512};


void f(int* table, int n)
{
    int la[10];

    for(int i =0; i<10; ++i)
        la[i]=ga[i];

    for(int i =0; i<10; ++i)
        cout<<ga[i]<<" ";

    int* p = new int[n];

    for(int i =0; i<n; ++i)
        p[i] = table[i];

    for(int i =0; i<n; ++i)
        cout<<p[i]<<" ";

    delete[] p;

}


int main()
{

f(ga, 10);

int aa[10] = {1, 2*1, 3*2*1, 4*3*2*1, 5*4*3*2*1, 6*5*4*3*2*1, 7*6*5*4*3*2*1, 8*6*5*4*3*2*1, 9*8*7*6*5*4*3*2*1, 10*9*8*7*6*5*4*3*2*1}; 
cout<<"\n\n";
f(aa, 10);

}