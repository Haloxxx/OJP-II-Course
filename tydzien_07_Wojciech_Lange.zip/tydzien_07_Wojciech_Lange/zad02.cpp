#include "std_lib_facilities.hpp"


struct God
{
    string name;
    string mythology;
    string vehicle;
    string weapon;
};


bool operator==(God a, God b)
{
    return a.mythology==b.mythology && a.name==b.name && a.vehicle==b.vehicle && a.weapon==b.weapon;
}


class Link{
    public:
        God value;

        Link(const God& v, Link* p = nullptr, Link* s = nullptr)
            : value{v}, prev{p}, succ{s}{}

        Link* insert(Link* n);
        Link* add(Link* n);
        Link* add_ordered(Link* n, int i);
        Link* erase(Link* p);
        Link* find(Link* p, const God& s);
        const Link* find(const God& s) const;

        Link* advance(Link* p, int n) const;

        Link* next() const { return succ;}
        Link* previous() const { return prev; }

    private:
        Link* prev;
        Link* succ; 
};

Link* Link::add(Link* n)
{
    if (n==nullptr) return this;
    if (this==nullptr) return n;
    n->prev = this;
    if(succ) n->succ=succ;
    succ = n;
    return n;

/*
    if (n==nullptr) return this;
    if (this==nullptr) return n;
    n->succ = this;
    if (prev) prev->succ = n;
    n->prev = prev;
    prev = n;
    return n;
*/
}


Link* Link::erase(Link* p)
{
    if (p==nullptr) return nullptr;
    if (p->succ) p->succ->prev = p->prev;
    if (p->prev) p->prev->succ = p->succ;
    return p->succ;
}

Link* Link::find(Link* p, const God& s)
{
    while (p){
        if (p->value == s) return p;
        p = p->succ;
    }
    return nullptr;
}

Link* Link::advance(Link* p, int n) const
{
    if(p==nullptr) return nullptr;
    if(0<n) {
        while (n--){
            if (p->succ=nullptr) return nullptr;
            p = p->prev;
        }
    }
    return p;
}


Link* Link::Link::insert(Link* n)
{
    if (n==nullptr) return this;
    if (this==nullptr) return n;
    n->succ = this;
    if (prev) prev->succ = n;
    n->prev = prev;
    prev = n;
    return n;
}

/*ostream& operator<<(ostream& os, const God& god) {
    return os << god.name << " " << god.mythology <<" "<<god.vehicle<< " "<<god.weapon<<'\n';
}*/


Link* Link::Link::add_ordered(Link* n, int i = 0)
{
    if (n==nullptr) return this;
    if (this==nullptr) return n;


    Link* parser;

    parser = this;


    while(true)
    {

        //cout<<"powtorzenie\n";
        if (this->value.name[i]<n->value.name[i])
        {
            if(parser->next()) parser = parser->next();
            else
            {
            parser->add(n);
            //cout<<"add\n";
            return parser;
            }
        }
        if(this->value.name[i]>n->value.name[i])
        {   if(parser->previous()) parser = parser->previous();
            else
            {
            parser->insert(n);
            //cout<<"insert\n";
            return parser;
            }
        }

        if(this->value.name[i]==n->value.name[i]) ++i;
        if(this->value.name==n->value.name) return parser;
        
    }

    return n;
}

void print_all(Link* p) {

    while (p) {
    cout << p->value.name<<", "<<p->value.mythology<<", "<<p->value.vehicle<< ", "<<p->value.weapon<<'\n';
    p=p->next();
    }
    

}



int main()
{

    God Zeus {"Zeus", "Greek", "", "lightning"};
    God Odin {"Odin", "Norse", "Eight-legged flying horse called Sleipner", "Spear called Gungnir"};
    God Poseidon {"Poseidon", "Greek", "", "trident"};
    God Mars {"Mars", "Roman", "", "sword"};
    God Athena {"Athena", "Greek", "", "sword"};
    God Saturn {"Saturn", "Roman", "", "sickle"};
    God Loki {"Loki", "Norse", "", ""};
    God Thor {"Thor", "Norse", "", "hammer"};
    God Vesta {"Vesta", "Roman", "", ""};


    Link* gods = new Link{Odin};
    gods = gods->add(new Link{Zeus});
    gods = gods->add(new Link{Poseidon});
    gods = gods->add(new Link{Mars});
    gods = gods->add(new Link{Athena});
    gods = gods->add(new Link{Saturn});
    gods = gods->add(new Link{Loki});
    gods = gods->add(new Link{Thor});
    gods = gods->add(new Link{Vesta});

    //cout<<"name = "<<gods->value.name<<'\n';

    Link* greek;
    Link* roman;
    Link* norse;

    do
    {
        if(gods->value.mythology=="Greek")
            greek = greek->add_ordered(new Link{gods->value});
        if(gods->value.mythology=="Roman")
            roman = roman->add_ordered(new Link{gods->value});
        if(gods->value.mythology=="Norse")
            norse = norse->add_ordered(new Link{gods->value});

        /*if(gods->previous())*/ gods=gods->previous();
    } while(gods->previous());

    if(gods->value.mythology=="Greek")
            greek = greek->add_ordered(new Link{gods->value});
        if(gods->value.mythology=="Roman")
            roman = roman->add_ordered(new Link{gods->value});
        if(gods->value.mythology=="Norse")
            norse = norse->add_ordered(new Link{gods->value});
    


    while(greek->previous()) greek = greek->previous();
    while(roman->previous()) roman = roman->previous();
    while(norse->previous()) norse = norse->previous();


    print_all(greek);
    cout<<"\n\n\n";
    print_all(roman);
    cout<<"\n\n\n";
    print_all(norse);
    cout<<"\n\n\n";
    
}