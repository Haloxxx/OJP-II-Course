#include "std_lib_facilities.hpp"

int area(int length, int width);

int main()
{
    int s1 = area(7;
    int s2 = area(7)
    Int s3 = area(7);
    int s4 = area('7);
}
