#include "std_lib_facilities.hpp"

int area(int length, int width);

int main()
{
    int x0 = arena(7);
    int x1 = area(7);
    int x2 = area("seven",2);
    
}
