//
//  try07.cpp
//  
//
//  Created by Wojciech Lange on 02/03/2019.
//

#include <stdio.h>


int main()
{
    
}
