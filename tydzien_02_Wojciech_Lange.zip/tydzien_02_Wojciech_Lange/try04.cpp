#include "std_lib_facilities.hpp"

int main()
{
    int area;
    
    cin>>area;
    
    if (area<=0) error("area is not positive");
    
    
    
}
