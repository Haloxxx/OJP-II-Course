#include "std_lib_facilities.hpp"


unsigned int factorial(unsigned int n)
{
    if(n<0) error("Negative value for factorial!");
    if (n == 0)
        return 1;
    return n * factorial(n - 1);
}


double formula(int a, int b)
{
    if(a<=0||b<=0) error("Negative or neutral value!");
    return factorial(a)/double(factorial(a-b));
}

double formula2(int a, int b)
{
    if(a<=0||b<=0) error("Negative or neutral value!");
    return formula(a,b)/double(factorial(b));
}


void permutations(int set, int word)
{
    if(set<=0||word<=0) error("Negative or neutral value!");
    
    cout<<"The number of permutations is: "<<formula(set, word)<<'\n';
    
}

void combinations(int set, int word)
{
    if(set<=0||word<=0) error("Negative or neutral value!");
    
    cout<<"The number of combinations is: "<<formula2(set,word)<<'\n';
}


int main()
{
    int val1, val2;
    char variant;
    
    cout<<"Please enter two numbers:\n";
    
    cin>>val1>>val2;
    
    if(val1<=0||val2<=0) error("Negative or neutral input!");
    
    
    cout<<"Do you want permutations or combinations? (p or c):\n";
    
    cin>>variant;
    
    switch(variant)
    {
        case 'p':
            permutations(val1,val2);
            break;
            
        case 'c':
            combinations(val1,val2);
            break;
            
        default:
            cout<<"Symbol not recognised!\n";
    }
    
    
    
}
