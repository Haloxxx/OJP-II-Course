#include "std_lib_facilities.hpp"
#include <vector>


void output(const vector<int>& table, int n)
{
    for(int i =0; i<n;++i) cout<<table[i];
    
}


int main()
{
    int n_values = -5;
    vector<int> numbers;
    int input;
    int sum = 0;
    string line;

        
    cout<<"Please enter the number of values you want to sum:\n";
    
    cin>>n_values;
    
    if(n_values<=0) error("Negative value or zero!");
    
    cout<<"Please enter some integers (press '|' to stop):\n";

    
    while(cin>>input)
    {
        numbers.push_back(input);
    }
    
    
    if(n_values>numbers.size()) error("Vector is too small\n");
    
    
    for(int i =0; i<n_values;++i)
    {
        sum+=numbers[i];
        line+=to_string(numbers[i])+" ";
    }
    cout<<"The sum of the first "<<n_values<<" numbers ( "<<line<<") is "<<sum<<'\n';
    
    
    
    
    
    
}
