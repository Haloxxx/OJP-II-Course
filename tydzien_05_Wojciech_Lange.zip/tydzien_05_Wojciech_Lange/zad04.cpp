
//
// This is example code from Chapter 12.3 "A first example" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
//

#include "Simple_window.hpp"    // get access to our window library
#include "Graph.hpp"            // get access to our graphics library facilities

//------------------------------------------------------------------------------

int main()
{
    using namespace Graph_lib;   // our graphics facilities are in Graph_lib
    
    Point tl(100,100);           // to become top left  corner of window
    
    
    int x_size = 800;
    int y_size = 800;
    int x_grid = 100;
    int y_grid = 100;
    
    Lines grid;
    for (int x=x_grid; x<x_size; x+=x_grid)
        grid.add(Point{x,0},Point{x,y_size});
    for (int y = y_grid; y<y_size; y+=y_grid)
            grid.add(Point{0,y},Point{x_size,y});
    

    Simple_window win(tl,800,1000,"Canvas");    // make a simple window

    
    Vector_ref<Rectangle> rect;
    for(int i=0; i<8; ++i)
    {
        rect.push_back(new Rectangle{Point{i*100,100*i},100,100});
        rect[rect.size()-1].set_fill_color(Color::red);
        rect[rect.size()-1].set_color(Color::invisible);
        win.attach(rect[rect.size()-1]);
    }
    
    Image mieszko {Point{0,200},"mieszko.jpg"};
    mieszko.set_mask(Point{150,0},200,200);
    
    Image mieszko2 {Point{0,400},"mieszko1.jpg"};
    mieszko2.set_mask(Point{150,0},200,200);
    
    Image mieszko3 {Point{0,600},"mieszko2.jpg"};
    mieszko3.set_mask(Point{150,0},200,200);
    
    
    win.attach(mieszko);
    win.attach(mieszko2);
    win.attach(mieszko3);
    win.attach(grid);
    
    
    for(int i = 0; i<8; ++i)
    {
        for(int j=0; j<8; ++j)
        {
            Image bolek {Point{100*j,100*i},"bolek.jpg"};
            bolek.set_mask(Point{170,100},100,100);
            win.attach(bolek);
            
            win.wait_for_button();       // give control to the display engine
        }
    }
    win.wait_for_button();
}

//------------------------------------------------------------------------------
