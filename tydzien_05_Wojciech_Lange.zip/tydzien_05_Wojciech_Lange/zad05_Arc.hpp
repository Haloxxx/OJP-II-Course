


struct Arc : Shape
{
    Arc(Point p, int rr, int dg);
    
    void draw_lines() const;
    
    Point center() const;
    int radius() const { return r; }
    void set_radius(int rr)
    {
        set_point(0,Point{center().x-rr,center().y-rr});
        
        r = rr;
    }
    
private:
    int r;
    
};

Arc::Arc(Point p, int rr, int dg)
:r{rr}:d{dg}
{
    add(Point{p.x-r,p.y-r});
}

Point Arc::center() const
{
    return {point(0).x+r,point(0).y+r};
}

void Arc::draw_lines() const
{
    if (color().visibility())
        fl_arc(point(0).x,point(0).y,r+r,r+r,0,d);
}


