
//
// This is example code from Chapter 12.3 "A first example" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
//

#include "Simple_window.hpp"    // get access to our window library
#include "Graph.hpp"            // get access to our graphics library facilities

//------------------------------------------------------------------------------

int main()
{
    using namespace Graph_lib;   // our graphics facilities are in Graph_lib

    Point tl(100,100);           // to become top left  corner of window

    Simple_window win(tl,600,400,"zad02");    // make a simple window

    Rectangle r {Point{200,200}, 100, 50};
    r.set_color(Color::blue);
    
    
    Closed_polyline poly_rect;
    poly_rect.add(Point{100,50});
    poly_rect.add(Point{200,50});
    poly_rect.add(Point{200,100});
    poly_rect.add(Point{100,100});
    
    poly_rect.set_color(Color::red);
    
    Rectangle r2 {Point{200,100}, 100, 30};
    Text t {Point{230,120}, "Howdy!"};
    
    
    Open_polyline w;
    
    w.add(Point{320,70});
    w.add(Point{320,200});
    w.add(Point{380,120});
    w.add(Point{440,200});
    w.add(Point{440,70});
    
    w.set_style(Line_style(Line_style::solid,8));
    w.set_color(Color::yellow);
    
    Open_polyline l;
    
    l.add(Point{470,70});
    l.add(Point{470,200});
    l.add(Point{565,200});
    
    l.set_style(Line_style(Line_style::solid,8));
    l.set_color(Color::red);
    
    Mark dot {Point{455,200},'o'};
    
    
    Rectangle p1 {Point{350,200}, 20, 20};
    Rectangle p2 {Point{370,200}, 20, 20};
    Rectangle p3 {Point{390,200}, 20, 20};
    Rectangle p4 {Point{350,220}, 20, 20};
    Rectangle p5 {Point{370,220}, 20, 20};
    Rectangle p6 {Point{390,220}, 20, 20};
    Rectangle p7 {Point{350,240}, 20, 20};
    Rectangle p8 {Point{370,240}, 20, 20};
    Rectangle p9 {Point{390,240}, 20, 20};
    
    p1.set_fill_color(Color::white);
    p3.set_fill_color(Color::white);
    p5.set_fill_color(Color::white);
    p7.set_fill_color(Color::white);
    p9.set_fill_color(Color::white);
    
    p2.set_fill_color(Color::red);
    p4.set_fill_color(Color::red);
    p6.set_fill_color(Color::red);
    p8.set_fill_color(Color::red);
    
    
    Circle face {Point{50,300},100};
    Circle oko1 {Point{60,310},5};
    Circle oko2 {Point{110,310},5};
    
    Line usta {Point{50,380},Point{110,380}};
    
    
    win.attach(r);
    win.attach(poly_rect);
    win.attach(r2);
    win.attach(t);
    win.attach(w);
    win.attach(l);
    win.attach(dot);
    
    win.attach(p1);
    win.attach(p2);
    win.attach(p3);
    win.attach(p4);
    win.attach(p5);
    win.attach(p6);
    win.attach(p7);
    win.attach(p8);
    win.attach(p9);
    
    win.attach(face);
    win.attach(oko1);
    win.attach(oko2);
    win.attach(usta);
    
    
    win.wait_for_button();       // give control to the display engine
}

//------------------------------------------------------------------------------
