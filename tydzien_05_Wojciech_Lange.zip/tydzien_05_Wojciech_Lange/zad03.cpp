
//
// This is example code from Chapter 12.3 "A first example" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
//

#include "Simple_window.hpp"    // get access to our window library
#include "Graph.hpp"            // get access to our graphics library facilities
#include <cmath>

//------------------------------------------------------------------------------

int sgn(double t)
{
    if (t>0) return 1;
    if (t == 0 ) return 0;
    if (t<0) return -1;
    
    return 55;
}


int main()
{
    using namespace Graph_lib;   // our graphics facilities are in Graph_lib

    double a = 0,b = 0,n = 0,m = 0;
    int number;
    
    
    std::cout<<"Please enter a, b, m, n and N - number of arguments:\n";
    std::cin>>a>>b>>m>>n>>number;
    
    
    Vector_ref<Point> points;
    vector<int> param = {-500,4,700,200,800};
    
    
    Point tl(100,100);           // to become top left  corner of window
    
    Simple_window win(tl,600,400,"Canvas");    // make a simple window
    
    
    
    for (int i =0; i<number; ++i)
    {
        double x,y;
        int t = param[i%5];
        x = pow(abs(cos(t)),2/m)*a*sgn(cos(t));
        y = pow(abs(sin(t)),2/n)*b*sgn(sin(t));
        
        
        points.push_back(new Point{static_cast<int>(x),static_cast<int>(y)});
    }
    Closed_polyline result;
    for (int i =0; i<number; ++i)
    {
        result.add(points[i]);
    }
    
    win.attach(result);
    
    
    win.wait_for_button();       // give control to the display engine
}

//------------------------------------------------------------------------------
