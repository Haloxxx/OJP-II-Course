struct Box : Shape
{
    Box(Point xy, int ww, int hh) : w(ww), h(hh)
    {
        add(xy);
        if (h<=0 || w<=0) error("Bad box: non-positive side");
    }
    
    Box(Point x, Point y) : w(y.x-x.x), h(y.y-x.y)
    {
        add(x);
        if (h<=0 || w<=0) error("Bad box: non-positive width or height");
    }

    void draw_lines() const;
    
    int height() const { return h; }
    int width() const { return w; }


private:
    int h;    // height
    int w;    // width


};
