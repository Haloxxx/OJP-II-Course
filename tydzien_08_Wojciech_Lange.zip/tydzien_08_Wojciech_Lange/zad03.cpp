#include "std_lib_facilities.hpp"

int main()
{
    string text = "slowo";
    string dwa = "\n12\n34\n";

    regex pat {R"(.+)"}; //kropka rozpoznaje \n

    smatch matches;

    if(regex_search(text, matches, pat))
    {
        cout<<text<<'\n';
    }

    if(regex_search(dwa, matches, pat))
    {
        cout<<dwa<<'\n';
    }

}