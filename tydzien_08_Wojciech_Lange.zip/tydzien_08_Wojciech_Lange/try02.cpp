#include "std_lib_facilities.hpp"

int main()
{
/*
AWK – interpretowany język programowania, którego
główną funkcją jest wyszukiwanie i przetwarzanie
wzorców w plikach lub strumieniach danych.

Perl – interpretowany, dynamiczny język programowania
wysokiego poziomu autorstwa Larry’ego Walla
początkowo przeznaczony głównie do pracy z danymi
tekstowymi, obecnie używany do wielu innych zastosowań. Wzorowany na takich językach jak C,
skryptowe: sed, awk i sh oraz na wielu innych.

PHP – interpretowany skryptowy język programowania
zaprojektowany do generowania stron internetowych
i budowania aplikacji webowych w czasie rzeczywistym.

John Maddock is a software developer from England and holds a PhD in Chemistry, but found that computers
smell less and explode less often!

John is the author of the regex++ regular expression package, has an almost pathological interest in anything that
"can't be done", and can be contacted at john@johnmaddock.co.uk.

*/
}