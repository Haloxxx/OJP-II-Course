#include "std_lib_facilities.hpp"


int main()
{
    string plik = "zad03.txt";
    
    ifstream read {plik};
    if (!read) error("File error!");
    
    
    int input;
    string skip;
    
    vector<int> numbers;
    
    
    while(true)
    {
        if(read>>input)
        {
            numbers.push_back(input);
        }
        else
        {
            read.clear();
            read>>skip;
        }
        
        if(read.eof()) break;
    }
    
    
    int sum;
    for(int j : numbers) sum+=j;
    
    cout<<sum<<'\n';
}
