#include "std_lib_facilities.hpp"




int comparison(const string& file1, const string& file2)
{
    cout<<"test\n";
    
    
    if (file1.length()>=file2.length())
    {
        for(int i =0; i<file2.length(); ++i)
        {
            if(file1[i]>file2[i])
            {
                //cout<<"test1\n";
                return 1;
            }
            if(file1[i]<file2[i])
            {
                //cout<<"test2\n";
                return 2;
            }
        }
        
        return 3;
    }
    else
    {
        for(int i =0; i<file1.length(); ++i)
        {
            if(file1[i]>file2[i])
            {
                //cout<<"test3\n";
                return 1;
            }
            if(file1[i]<file2[i])
            {
                //cout<<"test4\n";
                return 2;
            }
        }
        return 3;
    }
    
    
}



int main()
{
    
    string file1_name = "plik1.txt";
    string file2_name = "plik2.txt";
    string result = "result.txt";
    
    vector<string> file1;
    vector<string> file2;
    vector<string> sum;
    /*
    char stop;
    cout<<"rozmira = "<<file1.size();
    cin>>stop;
    */
    
    ifstream stream1 {file1_name};
    ifstream stream2 {file2_name};
    
    if (!stream1) error("File 1 error!");
    if (!stream2) error("File 2 error!");
    
    
    string temp1, temp2;
    
    while(stream1>>temp1) file1.push_back(temp1);
    while(stream2>>temp2) file2.push_back(temp2);
    
    
    
    
    int full_size = file1.size()+file2.size();
    
    /*if (file1.size()>file2.size()) full_size = file2.size();
    else full_size = file1.size();
    */
    
    ofstream print {result};
    
    int it1 = file1.size()-1, it2 = file2.size()-1;
    /*
    string a;
    
    a = file2[it2];
    */
    
    
    for(int i = 0; i<full_size; ++i)
    {
    
            switch(comparison(file1[it1],file2[it2]))
            {
                case 1:
                    sum.push_back(file1[it1]);
                    file1.pop_back();
                    if (file1.size()==0) i=full_size+100;
                    it1--;
                    break;
                    
                case 2:
                    //print<<file2[it2]<<" ";
                    sum.push_back(file2[it2]);
                    file2.pop_back();
                    if (file2.size()==0) i=full_size+100;
                    it2--;
                    break;
                    
                case 3:
                    sum.push_back(file1[it1]);
                    file1.pop_back();
                    file2.pop_back();
                    if (file1.size()==0) i=full_size+100;
                    if (file2.size()==0) i=full_size+100;
                    it1--;
                    it2--;
                    break;
            }
        
        
        cout<<"iter = "<<i<<'\n';
        cout<<"it1 = "<<it1<<'\n';
        cout<<"it2 = "<<it2<<'\n';
    }
    if(it1>0)
        for(int o = 0; o<=it1;++o) sum.push_back(file1[it1-o]);
    else if (it2>0)
        for(int o = 0; o<=it2;++o) sum.push_back(file2[it2-o]);
    
    
    
    for(int l =0; l<sum.size();++l) print<<sum[sum.size()-1-l]<<" ";
    
}
