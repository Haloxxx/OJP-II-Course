#include "std_lib_facilities.hpp"

int main()
{
    int a;
    int b;
    int c;
    int d;
    cin>>a>>hex>>b>>oct>>c>>d;
    cout<<a<<'\t'<<b<<'\t'<<c<<'\t'<<d<<'\n';
    
    /*
     Wejście: 1234 1234 1234 1234
     
     
     Pierwsze 1234 pozostaje niezmienione, ponieważ jest zapisane w postaci dziesiętnej.
     Przy drugim dochodzi do zamiany na system heksadecymalny.
     Trzeci i czwarty dają to samo, ponieważ modyfikator 'oct' pozostaje ustawiony dla strumienia.
     */
    
    
}
