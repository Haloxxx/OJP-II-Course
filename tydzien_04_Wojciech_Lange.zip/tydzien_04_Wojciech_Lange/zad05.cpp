#include "std_lib_facilities.hpp"


struct wynik
{
    string input;
    string typ;
    int output;
};


int hex_to_dec(const string& number)
{
    int result = 0, konwerter;
    
    for(int i =0; i<number.length();++i)
    {
        konwerter = number[number.length()-1-i]-'0';
        result+=konwerter*pow(16,i);
    }
    return result;
}



int dec_to_dec(const string& number)
{
    int result = 0, konwerter;
    
    for(int i =0; i<number.length();++i)
    {
        konwerter = number[number.length()-1-i]-'0';
        result+=konwerter*pow(10,i);
    }
    return result;
}


int oct_to_dec(const string& number)
{
    int result = 0, konwerter;
    
    for(int i =0; i<number.length();++i)
    {
        konwerter = number[number.length()-1-i]-'0';
        result+=konwerter*pow(8,i);
    }
    return result;
}


int main()
{
    
    cout<<"Enter several integers with prefixes:\n";

    string number;

    int liczba;
    
    vector<wynik> wyniki;
    
    
    while(cin>>number)
    {
        string prefix;
        string meat;
        
        
        prefix+=number[0];
        if (number.length()>1) prefix+=number[1];
        
        //1. case
        if (prefix[0]!='0' && prefix[1]!='1')
        {
            liczba = dec_to_dec(number);
            
            wyniki.push_back(wynik{number,"decimal    ",liczba});
        }
        
        
        
        //2. case
        if (prefix=="0x")
        {
            
            for(int o =2; o<number.length();++o) meat+=number[o];
            liczba = hex_to_dec(meat);
            
            wyniki.push_back(wynik{number,"hexadecimal",liczba});
        }
        
        
        
        ///3. case
        if (prefix[0]=='0' && prefix[1]!='x')
        {
            for(int o =1; o<number.length();++o) meat+=number[o];
            liczba = oct_to_dec(meat);
            
            
            wyniki.push_back(wynik{number,"octal      ",liczba});
        }
        
    }
    
    for(int u = 0; u<wyniki.size();++u)
    {
        cout<<setw(6)<<wyniki[u].input<<" "/*<<setw(11)*/<<wyniki[u].typ<<" converts to  "<<wyniki[u].output<<" decimal\n";
    }
    
}
