#include "std_lib_facilities.hpp"

int main()
{
    int date = 1998;
    int age = 21;
    
    
    cout<<"Decimal: \t"<<date<<"\nHexadecimal: \t"<<hex<<date<<"\nOctal: \t\t"<<oct<<date<<'\n';
    
    cout<<dec<<"Decimal: \t"<<age<<"\nHexadecimal: \t"<<hex<<age<<"\nOctal: \t\t"<<oct<<age<<'\n';
}
