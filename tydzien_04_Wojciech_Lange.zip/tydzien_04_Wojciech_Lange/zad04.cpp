#include "std_lib_facilities.hpp"


int main()
{
    
    int birth_year = 1998;
    
    cout<<showbase<<dec<<"decimal: \t"<<birth_year<<'\n'<<"hexadecimal: \t"<<hex<<birth_year<<'\n'<<"octal: \t\t"<<oct<<birth_year<<'\n';
    
    cout<<dec<<20<<'\n';
    
    int a,b,c,d;
    
    cin >> a >>oct >> b >> hex >> c >> d;
    cout << a << '\t'<< b << '\t'<< c << '\t'<< d << '\n' ;
    
    //Liczby b,c,d zostały wczytane jako liczby wyrażone w innych systemach, a następnie wyświetlone
    //w systemie dziesiętnym.
    
    double number = 1234567.89;
    
    cout<<number<<" "<<scientific<<number<<" "<<fixed<<number<<'\n';
    
    //Reprezentacja 'fixed' jest najdokładniejsza, ponieważ bez zaokrąglania wyświetla
    //wszystkie liczby po przecinku
    cout<<"\n\n\n\n\n";
    cout<<'|'<<setw(11)<<" Lange "<<'|'<<setw(10)<<" Wojciech "<<'|'<<" "<<123456789<<" |"<<setw(20)<<" email@adres.com |\n";
    cout<<'|'<<setw(11)<<" Rydziński "<<'|'<<setw(10)<<" Bartosz "<<'|'<<" "<<123546789<<" |"<<" email1@adres.com |\n";
    cout<<'|'<<setw(11)<<" Szulc "<<'|'<<setw(10)<<" Norbert "<<'|'<<" "<<123546798<<" |"<<" email2@adres.com |\n";
    cout<<'|'<<setw(12)<<" Fijołek "<<'|'<<setw(10)<<" Daniel "<<'|'<<" "<<213546789<<" |"<<" email3@adres.com |\n";
    cout<<'|'<<setw(12)<<" Kapłanek "<<'|'<<setw(10)<<" Karol "<<'|'<<" "<<123564789<<" |"<<" email4@adres.com |\n";
    cout<<'|'<<setw(11)<<" Frycki "<<'|'<<setw(10)<<" Piotr "<<'|'<<" "<<123546879<<" |"<<" email5@adres.com |\n";
}
