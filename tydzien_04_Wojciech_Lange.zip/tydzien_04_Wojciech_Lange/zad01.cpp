#include "std_lib_facilities.hpp"


struct Point
{
    int x, y;
};


int main()
{
    vector<Point> original_points;

    
    
    cout<<"Please enter 7 points: x,y\n";
    
    for (int i = 0; i<7; ++i)
    {
        Point p;
        char coma;
        
        cin>>p.x;
        cin>>coma;
        if (coma != ',') error("Invalid character");
        cin>>p.y;
        
        original_points.push_back(p);
        cout<<"("<<p.x<<","<<p.y<<")\n";
    }
    
    cout<<"\n\n\n\n\n";
    
    cout<<"original_points:\n";
    
    for (int i =0; i<7; ++i)
    {
        cout<<"("<<original_points[i].x<<","<<original_points[i].y<<")\n";
    }
    
    
    ofstream print {"mydata.txt"};
    if(!print) error("can't open output file");
    
    for(Point p : original_points)
        print<<p.x<<" "<<p.y<<"\n";
    
    print.close();
    
    ifstream read {"mydata.txt"};
    if(!read) error("can't open output file");
    
    int first, second;
    vector<Point> processed_points;
    
    
    while (read>>first>>second) processed_points.push_back(Point{first,second});
    
    
    cout<<"\n\n\n\n\n\n";
    
    cout<<"original_points:\n";
    for (int i =0; i<7; ++i)
    {
        cout<<"("<<original_points[i].x<<","<<original_points[i].y<<")\n";
    }
    
    
    cout<<"processed_points:\n";
    
    for (int i =0; i<7; ++i)
    {
        cout<<"("<<processed_points[i].x<<","<<processed_points[i].y<<")\n";
    }
 
    
    if (original_points.size()!=processed_points.size()) cout<<"Something's wrong!\n";
    else
    {
        for (int i =0; i<original_points.size(); ++i)
        {
            if (original_points[i].x!=processed_points[i].x || original_points[i].y!=processed_points[i].y) cout<<"Something's wrong!\n";
        }
    }
    
    
}
