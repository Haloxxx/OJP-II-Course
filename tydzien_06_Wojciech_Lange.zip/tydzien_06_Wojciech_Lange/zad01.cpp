#include "std_lib_facilities.hpp"

class B1
{
public:
    
    virtual void vf()
    {
        cout<<"B1::vf()\n";
    }
    
    void f()
    {
        cout<<"B1::f()\n";
    }
    
    virtual void pvf() = 0; //we have to override it in some other class
};


class D1 : public B1
{
public:
    
    void vf()
    {
        cout<<"D1::vf()\n";
    }
    
    void f()
    {
        cout<<"D1::f()\n";
    }
};

class D2 : public D1
{
public:
    
    void pvf() override
    {
        cout<<"D2::pvf()\n";
    }
};

class B2
{
public:
    
    virtual void pvf()=0;
    
    
};


class D21 : public B2
{
    string data = "fajnie";
    
public:
    
    void pvf() override
    {
        cout<<data<<"\n";
    }
};

class D22 : public B2
{
    int data = 0;
    
public:
    
    void pvf() override
    {
        cout<<data<<"\n";
    }
};

void f(B2& object)
{
    object.pvf();
}



int main()
{
 /*
    B1 object;
    
    object.vf();
    object.f();
    //uses B1 functions
    
    D1 object2;
    cout<<"\n\n\n";
    object2.vf();
    object2.f();
    //uses D1 functions
    
    
    B1& ref = object2;
    cout<<"\n\n\n";
    ref.vf();
    ref.f();
    
    //uses B1 function f(), but not vf(), because that's virtual one
   */
    //cout<<"\n\n\n";
    
    /*
    D2 object3;
    object3.vf();
    object3.f();
    object3.pvf();
    */
    
    
    D21 object4;
    D22 object5;
    
    B2& ref3 = object4;
    B2& ref4 = object5;
    
    f(ref3);
    f(ref4);
    
    
}
