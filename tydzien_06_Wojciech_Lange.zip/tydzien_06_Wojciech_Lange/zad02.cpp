
//
// This is example code from Chapter 12.3 "A first example" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
//

#include "Simple_window.hpp"    // get access to our window library
#include "Graph.hpp"            // get access to our graphics library facilities

//------------------------------------------------------------------------------

struct Immobile_Circle : Graph_lib::Shape {
    Immobile_Circle(Point p, int rr);    // center and radius
    
    void draw_lines() const;
    
    Point center() const ;
    int radius() const { return r; }
    void set_radius(int rr) { r=rr; }
    void move(int dx, int dy) override;
private:
    int r;
};

//------------------------------------------------------------------------------

Immobile_Circle::Immobile_Circle(Point p, int rr)    // center and radius
:r(rr)
{
    add(Point(p.x-r,p.y-r));       // store top-left corner
}

//------------------------------------------------------------------------------

Point Immobile_Circle::center() const
{
    return Point(point(0).x+r, point(0).y+r);
}

//------------------------------------------------------------------------------

void Immobile_Circle::draw_lines() const
{
    if (color().visibility())
        fl_arc(point(0).x,point(0).y,r+r,r+r,0,360);
}

//------------------------------------------------------------------------------

void Immobile_Circle::move(int dx, int dy)
{
    
}



struct Striped_rectangle : Graph_lib::Shape {
    
    
    Striped_rectangle(Point xy, int ww, int hh) : w(ww), h(hh)
    {
        add(xy);
        if (h<=0 || w<=0) error("Bad rectangle: non-positive side");
        
        for(int i = 0; i<h; i+=2)
        {
            //stripes.push_back(new Graph_lib::Line{Point{point(0).x,point(0).y+i},Point{point(0).x+w,point(0).y+i}});
            stripes.add(Point{xy.x, xy.y+i}, Point{xy.x + ww - 1, xy.y+i});
            
        }
        
    }
    
    Striped_rectangle(Point x, Point y) : w(y.x-x.x), h(y.y-x.y)
    {
        add(x);
        if (h<=0 || w<=0) error("Bad rectangle: non-positive width or height");
        
        for(int i = 0; i<h; i+=2)
        {
            //stripes.push_back(new Graph_lib::Line{Point{point(0).x,point(0).y+i},Point{point(0).x+w,point(0).y+i}});
            stripes.add(Point{x.x, x.y+i}, Point{y.x, y.y+i});
            
        }
    }
    void draw_lines() const;
    void set_stripes_color(Graph_lib::Color col);
    
    int height() const { return h; }
    int width() const { return w; }
private:
    int h;    // height
    int w;    // width
    Graph_lib::Lines stripes;
};

void Striped_rectangle::set_stripes_color(Graph_lib::Color col)
{
    stripes.set_color(col);
}

void Striped_rectangle::draw_lines() const
{
    if (fill_color().visibility()) {    // fill
        fl_color(fill_color().as_int());
        fl_rectf(point(0).x,point(0).y,w,h);
        //Graph_lib::Vector_ref<Graph_lib::Line> stripes;
        
    }
    
    if (color().visibility()) {    // lines on top of fill
        fl_color(color().as_int());
        fl_rect(point(0).x,point(0).y,w,h);
    }
    
    stripes.draw();
    
    
}

int main()
{
    using namespace Graph_lib;   // our graphics facilities are in Graph_lib

    Point tl(100,100);           // to become top left  corner of window

    Simple_window win(tl,600,400,"Canvas");    // make a simple window

    Immobile_Circle kolko(Point{250,100}, 50);
    
    win.attach(kolko);
    
    Striped_rectangle prostokat(Point{350,200}, 100, 50);
    win.attach(prostokat);
    
    win.wait_for_button();
    
    kolko.move(50,50);
    
    win.wait_for_button();
    // give control to the display engine
}

//------------------------------------------------------------------------------
