#include "std_lib_facilities.hpp"

int main()
{
    constexpr double d_per_y = 0.009017;
    constexpr double d_per_e = 1.134487;
    constexpr double d_per_p = 1.3063;
    
    double amount = 1;
    
    char cur = ' ';
    
    cout<<"Please enter an amount of money followed by a symbol of currency (y, e or p):\n";
    cin>>amount>>cur;
    
    if(cur == 'y')
        cout<<amount<<"y == "<<d_per_y*amount<<"d\n";
    else if (cur == 'e')
        cout<<amount<<"e == "<<d_per_e*amount<<"d\n";
    else if (cur == 'p')
        cout<<amount<<"p == "<<d_per_p*amount<<"d\n";
    else
        cout<<"Sorry, I don't know a currency called '"<<cur<<"'\n";
    
    
}
