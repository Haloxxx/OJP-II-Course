#include "std_lib_facilities.hpp"

int main()
{
    constexpr double d_per_y = 0.009017;
    constexpr double d_per_e = 1.134487;
    constexpr double d_per_p = 1.3063;
    constexpr double d_per_j = 0.14949;
    constexpr double d_per_k = 0.152060;
    
    double amount = 1;
    
    char cur = ' ';
    
    cout<<"Please enter an amount of money followed by a symbol of currency (y, e, p, j or k):\n";
    cin>>amount>>cur;
    
    
    switch(cur)
    {
        case 'y':
            cout<<amount<<"y == "<<d_per_y*amount<<"d\n";
            break;
        case 'e':
            cout<<amount<<"e == "<<d_per_e*amount<<"d\n";
            break;
        case 'p':
            cout<<amount<<"p == "<<d_per_p*amount<<"d\n";
            break;
        case 'j':
            cout<<amount<<"j == "<<d_per_j*amount<<"d\n";
            break;
        case 'k':
            cout<<amount<<"k == "<<d_per_k*amount<<"d\n";
            break;
        default:
            cout<<"Sorry, I don't know a currency called '"<<cur<<"'\n";
            break;
            
    }
    
    

    
}
