#include "std_lib_facilities.hpp"
#include <vector>

int main()
{
    
    char move_p, move_c;
    vector<char> moves;
    
    for(int i =0; i<10; ++i)
    {
        cout<<"Please enter the next move for the computer: (r, p, s)\n";
        cin>>move_c;
        
        switch(move_c)
        {
            case 'r': case 'p': case 's':
                moves.push_back(move_c);
                break;
            default:
                cout<<"That's not a legitimate input";
                break;
        }
        
        
    }
    
    char helper = moves[0];
    
    for(int i =0; i<10;++i)
    {
        if (i < 9)
            moves[i]=moves[i+1];
        else moves[i] = helper;
        
    }
    
    
    cout<<"The game starts! Enter your move!\n";
    
    for(int j=0;j<10;++j)
    {
        cin>>move_p;
        
        switch(move_p)
        {
            case 'r':
                
                switch(moves[j])
                {
                    case 'r':
                        cout<<"ROCK - DRAW\n";
                        break;
                    
                    case 'p':
                        cout<<"PAPER - LOSE\n";
                        break;
                    
                    case 's':
                        cout<<"SCISSORS - WIN\n";
                        break;
                   /*
                    defaut:
                        cout<<"ERROR!";
                        break;
                    */
                }
                break;
            case 'p':
                
                switch(moves[j])
                {
                case 'p':
                    cout<<"PAPER - DRAW\n";
                    break;
                    
                case 's':
                    cout<<"SCISSORS - LOSE\n";
                    break;
                    
                case 'r':
                    cout<<"ROCK - WIN\n";
                    break;
                 /*
                defaut:
                    cout<<"ERROR!";
                    break;
                   */
                }
                break;
                
                
            case 's':
                
                switch(moves[j])
                {
                case 's':
                    cout<<"SCISSORS - DRAW\n";
                    break;
                    
                case 'r':
                    cout<<"ROCK - LOSE\n";
                    break;
                    
                case 'p':
                    cout<<"PAPER - WIN\n";
                    break;
                 /*
                defaut:
                    cout<<"ERROR!";
                    break;
                   */
                }
                break;
                
                
            default:
                cout<<"It's not a legitimate input";
        }
    }
    
    
    
    
    
    
}
