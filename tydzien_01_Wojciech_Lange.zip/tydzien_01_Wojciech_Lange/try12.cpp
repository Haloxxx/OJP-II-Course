#include "std_lib_facilities.hpp"

int main()
{
    
    string disliked = "Broccoli";
    string disliked2 = "Potato";
    string disliked3 = "Pumpkin";
    string disliked4 = "Tomato";
    
    vector<string> words;
    
    for(string temp; cin>>temp; )
        words.push_back(temp);
    
    for (int i = 0; i<words.size();i++)
    {
        if (words[i]==disliked)
            cout<<"BLEEP ";
        else if (words[i]==disliked2)
            cout<<"BLEEP ";
        else if (words[i]==disliked3)
            cout<<"BLEEP ";
        else if (words[i]==disliked4)
            cout<<"BLEEP ";
        else cout<<words[i]<<" ";
    }
    
        
    
    
}
