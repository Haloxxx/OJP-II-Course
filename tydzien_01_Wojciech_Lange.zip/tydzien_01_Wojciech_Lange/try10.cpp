#include "std_lib_facilities.hpp"

int main()
{
    for (int i=0; i<26;i++)
    {
        cout<<char('a'+i)<<" "<<'a'+i<<'\n';
    }
    
    for (int i=0; i<26;i++)
    {
        cout<<char('A'+i)<<" "<<'A'+i<<'\n';
    }
    
    for (int i=0;i<10;i++)
        cout<<char('0'+i)<<" "<<'0'+i<<'\n';
}
