#include "std_lib_facilities.hpp"

int main()
{
    int i =0;
    
    while (i<26)
    {
        cout<<char('a'+i)<<" "<<'a'+i<<'\n';
        ++i;
    }
    
}
