#include "std_lib_facilities.hpp"

int main()
{
    string s = "Goodbye, cruel world! ";
    cout<<s<<'\n';
}
