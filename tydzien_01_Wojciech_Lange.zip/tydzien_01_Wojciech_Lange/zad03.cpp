#include "std_lib_facilities.hpp"

int main()
{
    char input;
    double smallest = 0,biggest = 0;
    double sum =0;
    int counter = 0;
    constexpr double cm_to_m = 0.01, in_to_cm = 2.54, ft_to_in = 12;
    vector<double> values;
    double val, val1;
    bool flag = false;
    string unit = "";
    
    
    
    
    while (input!='|')
    {
        
        flag = false;
        val = 0;
        
        
        while (flag==false)
        {
            flag=false;
            val1=0;
            unit="";
            
            cin.clear();
            cin>>val1>>unit;
            
            
            if (unit=="cm")
            {
                val = val1 * cm_to_m;
                flag = true;
            }
            else if (unit=="m")
            {
                val = val1;
                flag = true;
            }
            else if (unit=="in")
            {
                
                val = val1 * in_to_cm;
                val = val * cm_to_m;
                flag = true;
            }
            
            else if (unit=="ft")
            {
                val = val1 * ft_to_in;
                val = val * in_to_cm;
                val = val * cm_to_m;
                flag = true;
            }
            else
            {
             cout<<"Illegal unit\n";
             flag = false;
                
            }
        }
        
    
        
        
        
        
        
        
            cout<<val;
            
            if (val1>=biggest)
            {
                cout<<" the biggest so far\n";
                biggest = val;
            }
            if (val1<=smallest || smallest==0)
            {
                cout<<" the smallest so far\n";
                smallest = val;
            }
            
        
        
        
        
        
        sum += val;
        ++counter;
        
        values.push_back(val);
        
        
        
        cout<<"\nEnter any character to continue, '|' to break\n";
        cin>>input;
        
        
    }
    
    cout<<"The smallest is: "<<smallest<<'\n';
    cout<<"The largest is: "<<biggest<<'\n';
    cout<<"The number of values is: "<<counter<<'\n';
    cout<<"The sum of values is: "<<sum<<'\n';
    
    
    sort(values);
    
    for (int i =0; i<counter; i++)
    {
        cout<<values[i]<<" ";
    }
    
    
    
}
