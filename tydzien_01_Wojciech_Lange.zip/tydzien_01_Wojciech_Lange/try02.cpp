#include "std_lib_facilities.hpp"

int main()
{
    cout <<"Please enter an integer value: ";
    int n;
    double help;
    cin>>n;
    help = n;
    cout<<"n == "<<n
        <<"\nn+1 == "<<n+1
        <<"\nthree times n == "<<3*n
        <<"\ntwice n == "<<n+n
        <<"\nn squared == " << n*n
        <<"\nn half of n == "<<n/2<<" remainder == "<<n%2
        <<"\nsquare root of n == "<<sqrt(help)
        <<"\nn multiplied by 100 == "<<n*100
        <<"\nn plus 1000 == "<<n+1000
        <<'\n';
    
}
